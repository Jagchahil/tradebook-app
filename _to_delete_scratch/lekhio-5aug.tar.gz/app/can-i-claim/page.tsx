import type { Metadata } from 'next';
import Link from 'next/link';
import { EXPENSE_RULES, TAX_TIPS, VERDICT_LABEL, type Verdict } from '../../lib/taxrules';
import { RULE_SOURCES } from '../../lib/rulesources';
import LeadCapture from '../../components/LeadCapture';
// The nudge clause is empty until a deadline alert can actually be sent. See lib/features.ts.
import { nudgeClause } from '../../lib/features';
import { A11Y_CSS } from '../../lib/tokens';
import { SharedHead, SiteNav, SiteFooter } from '../_shared/site';

// ═══════════════════════════════════════════════════════════════════════════════════════════
// 🔴 THE MOST QUESTION SHAPED PAGE ON THE SITE, AND IT HAD NO STRUCTURED DATA AT ALL.
//
// Found on 4 August by widening a guard that had been asserting "same pattern as the other tool
// pages" about exactly one page. Widened once, it found /invoice-generator. Widened again, to the
// whole of the exported freeTools list rather than a hand typed eight, it found this one.
//
// Its own meta description is literally two questions: "Can I expense my work boots? Is a van tax
// deductible?" It is in freeTools, in the /resources grid, in the sitemap, it carries a canonical
// and it captures leads. Everything about it was built to win a question search except the one
// piece of markup that tells a search engine it answers questions.
//
// ⚠️ THE ANSWERS ARE THE PAGE'S OWN, taken from lib/taxrules.ts which is the same source the
// checker below answers from. A FAQ schema that says something the page does not say is a rich
// result that misrepresents the page, and nobody would ever notice from inside the code.
//
// ⚠️ AND NOT ONE OF THEM STATES A VERDICT MORE CONFIDENTLY THAN THE PAGE DOES. The whole point of
// this tool is that the grey areas are grey, so an answer that flattens one into a yes to win a
// snippet would be the tool lying in a place its own reader cannot see.
// ═══════════════════════════════════════════════════════════════════════════════════════
const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'Can I claim my work boots as a self employed expense?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Protective boots and safety gear you need for the job are allowable, and so is a uniform carrying your business name. Ordinary clothing is not, even if you only ever wear it for work, because it is also capable of everyday use.',
      },
    },
    {
      '@type': 'Question',
      name: 'Is a van tax deductible if I am self employed?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'A van is plant and machinery, so its cost usually comes off your profit in the year you buy it under the annual investment allowance. A car is different: cars do not qualify for that allowance and instead earn a writing down allowance each year for as long as you own it. Only the business share of the use is claimable either way.',
      },
    },
    {
      '@type': 'Question',
      name: 'Can I claim for working from home?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Yes. The simplest route is HMRC\u2019s flat rate, which needs no receipts and no bills kept, and rises with the hours you work from home each month. You can instead work out the actual share of your household costs, which can be worth more and needs the records to back it.',
      },
    },
    {
      '@type': 'Question',
      name: 'Can I claim a meal while I am out working?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'This is one of the grey ones. A meal on a genuine business journey away from your normal pattern of work can be allowable. Everyday lunches while working locally are not, because you would have had to eat regardless.',
      },
    },
  ],
};

export const metadata: Metadata = {
  alternates: { canonical: '/can-i-claim' },
  title: 'Can I claim it? UK self employed expenses, answered straight | Lekhio',
  description:
    'Can I expense my work boots? Is a van tax deductible? Lekhio answers the real allowable expense questions for UK sole traders, the grey areas included, all within the law. Ask it in your browser.',
  openGraph: {
    title: 'Can I claim it? Just ask Lekhio.',
    description:
      'The real rules on what UK sole traders can and cannot claim, the grey areas done properly, all legal. Ask it in your browser.',
    type: 'website',
  },
};

const INK = 'var(--tx)';
const RIVER = 'var(--river)';
const RIVER_DEEP = 'var(--river-deep)';
const RIVER_TINT = 'var(--river-tint)';
const SAFFRON_DEEP = 'var(--saffron-deep)';
// 🔴 ON a saffron tint the ink is ON_SAFFRON_TINT, not SAFFRON_DEEP. Deep on tint reads 2.70:1.
const ON_SAFFRON_TINT = 'var(--on-saffron-tint)';
const SAFFRON_TINT = 'var(--saffron-tint)';
const GREEN = 'var(--green)';
const ON_GREEN_TINT = 'var(--on-green-tint)';
const GREEN_TINT = 'var(--green-tint)';
const RED_INK = 'var(--red)';
const RED_TINT = 'var(--red-tint)';
const PAPER = 'var(--bg)';
const SURFACE = 'var(--surface)';
const LINE = 'var(--bd)';
const MUTED = 'var(--tx-mut)';
const FONT = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";

// 🔴 ON A TINT, THE INK IS THE ON TOKEN. This one function paints EVERY verdict pill on the page,
// so `fg: GREEN` on `bg: GREEN_TINT` failed AA fifteen times over as "Yes, claim it" rows, and
// SAFFRON_DEEP on its tint eleven times as "It depends". Two lines, twenty six failures. Both ON
// tokens are themed for dark, so this is correct in both appearances.
function verdictColours(v: Verdict): { fg: string; bg: string } {
  if (v === 'yes') return { fg: ON_GREEN_TINT, bg: GREEN_TINT };
  if (v === 'no') return { fg: RED_INK, bg: RED_TINT };
  return { fg: ON_SAFFRON_TINT, bg: SAFFRON_TINT };
}

const yesRules = EXPENSE_RULES.filter((r) => r.verdict === 'yes');
const midRules = EXPENSE_RULES.filter((r) => r.verdict === 'partly' || r.verdict === 'depends');
const noRules = EXPENSE_RULES.filter((r) => r.verdict === 'no');

// The four classic ones people get wrong, shown with the full detail.
const greyKeys = ['everyday_clothes', 'car', 'training', 'meals'];
const greyAreas = greyKeys
  .map((k) => EXPENSE_RULES.find((r) => r.key === k))
  .filter((r): r is (typeof EXPENSE_RULES)[number] => Boolean(r));

const demo: { side: 'out' | 'in'; text: string }[] = [
  { side: 'out', text: 'can I claim my work jeans?' },
  { side: 'in', text: 'Sorry, no. Everyday clothes are out, even if you only wear them on site. Branded uniform and protective gear like boots are in though.' },
  { side: 'out', text: 'what about my van?' },
  { side: 'in', text: 'Yes. A work van is allowable, the whole cost the year you buy it, or claim 55p a mile instead. 👍' },
];

// THE LINE THAT SAYS IT IS NOT US SAYING SO.
//
// Every other app in this category tells a man what he can claim and expects to be believed. We
// hand him the HMRC page and let him check. That is not a compliance ornament, it is the product:
// doc 104, "honesty is not a constraint we tolerate, it is the product we are selling."
//
// It is also the only claim on this page a competitor cannot copy this afternoon, because most of
// them could not survive somebody actually reading the source.
//
// SHOWN ONLY WHERE WE HAVE ONE. Eleven of the 24 rules are still uncited, and they are listed
// openly at /rules.json. But a badge on the card reading "no source" would frighten a man about a
// verdict that is almost certainly right, and he cannot act on it. Doc 103: a row he has to read
// and dismiss before he gets to what he came for is a row that should not be there. The honesty
// belongs on the public URL, where it is checkable. The card gets the authority or it gets nothing.
function Citation({ ruleKey }: { ruleKey: string }) {
  const sources = RULE_SOURCES[ruleKey];
  if (!sources || sources.length === 0) return null;
  const s = sources[0];
  return (
    <a
      href={s.url}
      target="_blank"
      rel="noopener noreferrer"
      style={{ fontSize: 12, color: MUTED, textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 5, marginTop: 2 }}
    >
      <span style={{ fontWeight: 600 }}>HMRC {s.code}</span>
      {/* 🔴 THIS SAID:  s.authority.split(';')[0]
          The authority field carries TWO different things, separated by a semicolon:
              "S34(1)(a) ITTOIA 2005; Mallalieu v Drummond [1983] 57 TC 330 (HL)"
               ^^^^ the statute        ^^^^ the House of Lords deciding what it means
          Taking [0] showed the statute and THREW THE CASE AWAY. So on the most contentious rule we
          have, the single strongest thing we can say for it, a House of Lords decision, never
          reached one user. Nobody meant to hide it. Nobody ever asked what the second half was for.
          The court outranks the guidance. Show it. */}
      {s.authority ? <span style={{ opacity: 0.75 }}>· {s.authority}</span> : null}
      <span aria-hidden style={{ opacity: 0.6 }}>↗</span>
    </a>
  );
}

function RuleCard({ r }: { r: (typeof EXPENSE_RULES)[number] }) {
  const c = verdictColours(r.verdict);
  return (
    <div className="rulecard" style={{ background: 'var(--panel)', border: `1px solid ${LINE}`, borderRadius: 16, padding: 20, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
        <h3 style={{ fontSize: 15.5, fontWeight: 700, margin: 0, letterSpacing: '-0.2px' }}>{r.title}</h3>
        <span style={{ flexShrink: 0, fontSize: 11, fontWeight: 700, letterSpacing: '0.3px', color: c.fg, background: c.bg, padding: '5px 10px', borderRadius: 12 }}>{VERDICT_LABEL[r.verdict]}</span>
      </div>
      <p style={{ fontSize: 14, color: MUTED, lineHeight: 1.55, margin: 0 }}>{r.rule}</p>
      <Citation ruleKey={r.key} />
    </div>
  );
}

function Group({ title, blurb, rules, accent }: { title: string; blurb: string; rules: typeof EXPENSE_RULES; accent: string }) {
  return (
    <div style={{ marginBottom: 30 }}>
      <div className="reveal" style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
        <span style={{ width: 10, height: 10, borderRadius: 5, background: accent }} />
        <h3 style={{ fontSize: 19, fontWeight: 800, margin: 0, letterSpacing: '-0.3px' }}>{title}</h3>
      </div>
      <p className="reveal" style={{ fontSize: 14.5, color: MUTED, margin: '0 0 18px', maxWidth: 620 }}>{blurb}</p>
      <div className="reveal rulegrid">
        {rules.map((r) => (
          <RuleCard key={r.key} r={r} />
        ))}
      </div>
    </div>
  );
}

export default function CanIClaimPage() {
  return (
    <main style={{ backgroundColor: PAPER, color: INK, fontFamily: FONT, overflowX: 'hidden' }}>
      <SharedHead />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <style
        dangerouslySetInnerHTML={{
          __html: `
          *{box-sizing:border-box} body{margin:0} a{text-decoration:none}
          @keyframes riseIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
          .reveal{opacity:1;transform:none}
          .reveal.in{opacity:1;transform:none}
          .h1{font-size:54px;line-height:1.05;letter-spacing:-2px}
          .h2{font-size:32px;line-height:1.14;letter-spacing:-0.7px}
          .rulegrid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
          .oneRule{display:grid;grid-template-columns:1.1fr .9fr;gap:36px;align-items:center}
          .rulecard{transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease}
          .rulecard:hover{transform:translateY(-4px);box-shadow:0 16px 36px rgba(17,17,17,.08);border-color:${RIVER_TINT}}
          .btn{transition:transform .18s ease,box-shadow .18s ease,background-color .18s ease}
          .btn:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(27,89,166,.28)}
          @media (max-width:880px){.h1{font-size:36px}.h2{font-size:25px}.rulegrid{grid-template-columns:1fr}.oneRule{grid-template-columns:1fr;gap:24px}.grey-grid{grid-template-columns:1fr!important}.tips-grid{grid-template-columns:1fr!important}}
          `,
        }}
      />
      <noscript><style dangerouslySetInnerHTML={{ __html: `.reveal{opacity:1;transform:none}` }} /></noscript>
      <style dangerouslySetInnerHTML={{ __html: A11Y_CSS }} />

      {/* Nav */}
      <SiteNav />

      {/* Hero */}
      <section style={{ maxWidth: 1180, margin: '0 auto', padding: '30px 24px 8px' }}>
        <div style={{ maxWidth: 720 }}>
          <span style={{ display: 'inline-block', backgroundColor: RIVER_TINT, color: RIVER_DEEP, fontSize: 12, fontWeight: 700, letterSpacing: '0.6px', padding: '6px 12px', borderRadius: 20, marginBottom: 20 }}>ASK LEKHIO</span>
          <h1 className="h1" style={{ fontWeight: 700, margin: '0 0 18px' }}>Can I claim it? Just ask.</h1>
          <p style={{ fontSize: 19, color: MUTED, lineHeight: 1.6, margin: '0 0 26px' }}>
            Half of paying less tax is just knowing what you are allowed to claim. Text Lekhio the thing, and get a straight answer in seconds. The real rules, the grey areas included, all fully within the law.
          </p>
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <Link href="/start" className="btn" style={{ backgroundColor: RIVER, color: 'var(--on-river)', fontSize: 16, fontWeight: 600, padding: '15px 30px', borderRadius: 12 }}>Start free trial</Link>
            <a href="#list" className="btn" style={{ backgroundColor: 'transparent', color: INK, border: `1px solid ${INK}`, fontSize: 16, fontWeight: 600, padding: '15px 30px', borderRadius: 12 }}>See the list</a>
          </div>
        </div>
      </section>

      {/* The one rule, and a worked example of asking it */}
      <section style={{ maxWidth: 1180, margin: '0 auto', padding: '34px 24px' }}>
        <div className="reveal oneRule">
          <div style={{ minWidth: 0 }}>
            <h2 className="h2" style={{ fontWeight: 700, margin: '0 0 14px' }}>One simple test runs the lot.</h2>
            <p style={{ fontSize: 16.5, color: MUTED, lineHeight: 1.65, margin: '0 0 16px' }}>
              HMRC allows a cost if it was spent <strong style={{ color: INK }}>wholly and exclusively for the business</strong>. If something is part business and part personal, like your phone or your car, you claim the business share, not all of it.
            </p>
            <p style={{ fontSize: 16.5, color: MUTED, lineHeight: 1.65, margin: 0 }}>
              That is it. No tricks, no dodgy loopholes. Just claiming everything you are legally owed, and not a penny you are not. Most people leave money on the table simply because they never asked.
            </p>
          </div>
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <div style={{ width: 300, maxWidth: '100%', background: 'var(--panel)', borderRadius: 26, border: `1px solid ${LINE}`, boxShadow: '0 24px 60px rgba(17,17,17,.14)', overflow: 'hidden' }}>
              {/* Own tokens, not Meta's. See the hero note in app/_shared/site.tsx. */}
              <div style={{ background: 'var(--river-deep)', color: 'var(--on-river)', padding: '12px 15px', display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ width: 32, height: 32, borderRadius: 16, background: 'var(--river)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>✅</span>
                <div><div style={{ fontSize: 13.5, fontWeight: 700 }}>Lekhio</div><div style={{ fontSize: 10.5, opacity: 0.85 }}>your first employee</div></div>
              </div>
              <div style={{ background: 'var(--panel-2)', padding: '16px 13px', display: 'flex', flexDirection: 'column', gap: 9 }}>
                {/* Themed surfaces, so the text can follow var(--tx) and no longer needs a hardcoded
                    dark ink to survive a light bubble that never flipped. */}
                {demo.map((m, i) => (
                  <div key={i} style={{ alignSelf: m.side === 'out' ? 'flex-end' : 'flex-start', background: m.side === 'out' ? 'var(--river-tint)' : 'var(--panel)', border: m.side === 'in' ? '1px solid var(--bd)' : 'none', borderRadius: m.side === 'out' ? '14px 14px 4px 14px' : '14px 14px 14px 4px', padding: '9px 12px', maxWidth: '86%', fontSize: 13, color: m.side === 'out' ? 'var(--river-deep)' : 'var(--tx)', lineHeight: 1.5 }}>{m.text}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* The list */}
      <section id="list" style={{ background: SURFACE, borderTop: `1px solid ${LINE}`, borderBottom: `1px solid ${LINE}` }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', padding: '46px 24px' }}>
          <div className="reveal" style={{ textAlign: 'center', marginBottom: 40 }}>
            <h2 className="h2" style={{ fontWeight: 700, margin: '0 0 12px' }}>What you can and cannot claim.</h2>
            <p style={{ fontSize: 16.5, color: MUTED, maxWidth: 560, margin: '0 auto' }}>The common ones for UK sole traders. Ask Lekhio about anything not here and it will tell you straight.</p>
          </div>
          <Group title="Yes, claim these in full" blurb="Straightforward business costs. Log them all, even the small ones, because every pound you miss is tax you did not need to pay." rules={yesRules} accent={GREEN} />
          <Group title="Part of it, or it depends" blurb="Mixed use or grey area items. You can claim, but only the business share or only in the right circumstances. Lekhio works out the right slice." rules={midRules} accent={SAFFRON_DEEP} />
          <Group title="Usually not, so do not risk it" blurb="The ones people wrongly try to claim. Getting these wrong invites trouble, so we keep you on the right side of the line." rules={noRules} accent={RED_INK} />
        </div>
      </section>

      {/* Grey areas done properly */}
      <section style={{ maxWidth: 1180, margin: '0 auto', padding: '50px 24px' }}>
        <div className="reveal" style={{ textAlign: 'center', marginBottom: 36 }}>
          <span style={{ display: 'inline-block', backgroundColor: SAFFRON_TINT, color: ON_SAFFRON_TINT, fontSize: 12, fontWeight: 700, letterSpacing: '0.6px', padding: '6px 12px', borderRadius: 20, marginBottom: 14 }}>THE GREY AREAS</span>
          <h2 className="h2" style={{ fontWeight: 700, margin: '0 0 12px' }}>The ones everyone gets wrong.</h2>
          <p style={{ fontSize: 16.5, color: MUTED, maxWidth: 600, margin: '0 auto' }}>Clothes, the car, training, meals. Here is the honest rule on each, so you claim what you can and steer clear of what you cannot.</p>
        </div>
        <div className="reveal grey-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
          {greyAreas.map((r) => {
            const c = verdictColours(r.verdict);
            return (
              <div key={r.key} style={{ background: 'var(--panel)', border: `1px solid ${LINE}`, borderRadius: 18, padding: 24 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                  <h3 style={{ fontSize: 17, fontWeight: 800, margin: 0 }}>{r.title}</h3>
                  <span style={{ fontSize: 11, fontWeight: 700, color: c.fg, background: c.bg, padding: '4px 10px', borderRadius: 12 }}>{VERDICT_LABEL[r.verdict]}</span>
                </div>
                <p style={{ fontSize: 14.5, color: MUTED, lineHeight: 1.6, margin: 0 }}>{r.detail}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Claim everything you are owed */}
      <section style={{ background: `linear-gradient(180deg, #fff, ${RIVER_TINT})`, borderTop: `1px solid ${LINE}` }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', padding: '50px 24px' }}>
          <div className="reveal" style={{ textAlign: 'center', marginBottom: 36 }}>
            <span style={{ display: 'inline-block', backgroundColor: 'var(--panel)', border: `1px solid ${LINE}`, color: RIVER_DEEP, fontSize: 12, fontWeight: 700, letterSpacing: '0.6px', padding: '6px 12px', borderRadius: 20, marginBottom: 14 }}>KEEP MORE, LEGALLY</span>
            <h2 className="h2" style={{ fontWeight: 700, margin: '0 0 12px' }}>The legal ways to pay less tax.</h2>
            <p style={{ fontSize: 16.5, color: MUTED, maxWidth: 600, margin: '0 auto' }}>Nothing dodgy, nothing risky. Just the reliefs and allowances people miss. Lekhio tracks most of these for you as you work.</p>
          </div>
          <div className="reveal tips-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {TAX_TIPS.map((t, i) => (
              <div key={t.title} style={{ display: 'flex', gap: 14, background: 'var(--panel)', border: `1px solid ${LINE}`, borderRadius: 14, padding: '18px 20px' }}>
                <span style={{ flexShrink: 0, width: 28, height: 28, borderRadius: 14, background: RIVER, color: 'var(--on-river)', fontSize: 13, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{i + 1}</span>
                <div>
                  <h3 style={{ fontSize: 15.5, fontWeight: 700, margin: '0 0 4px' }}>{t.title}</h3>
                  <p style={{ fontSize: 14, color: MUTED, lineHeight: 1.55, margin: 0 }}>{t.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Consent engine */}
      <section style={{ maxWidth: 720, margin: '0 auto', padding: '8px 24px 0' }}>
        <LeadCapture
          source="can-i-claim"
          heading="Get the claim answers"
          sub={`Pop your email in and we will send you a handy claim guide and your result.${nudgeClause()} No spam, unsubscribe any time.`}
        />
      </section>

      {/* CTA */}
      <section style={{ background: 'var(--band)' }}>
        <div className="reveal" style={{ maxWidth: 720, margin: '0 auto', padding: '54px 24px', textAlign: 'center' }}>
          <h2 className="h2" style={{ color: '#fff', fontWeight: 700, margin: '0 0 14px' }}>Stop overpaying. Just ask.</h2>
          <p style={{ fontSize: 16.5, color: '#B6BDC8', lineHeight: 1.6, maxWidth: 540, margin: '0 auto 28px' }}>
            Lekhio answers your claim questions in plain English, logs every cost as you go, and keeps you ready for tax. You always approve before anything is sent to HMRC.
          </p>
          <Link href="/start" className="btn" style={{ display: 'inline-block', backgroundColor: RIVER, color: 'var(--on-river)', fontSize: 16, fontWeight: 600, padding: '15px 32px', borderRadius: 12 }}>Start free trial</Link>
          <p style={{ fontSize: 13, color: '#8A93A0', marginTop: 22, maxWidth: 560, marginLeft: 'auto', marginRight: 'auto', lineHeight: 1.6 }}>
            General information, not tax advice for your exact situation. Lekhio is an independent UK company, not HMRC, and not endorsed by HMRC. Always check your own position with HMRC or an accountant if you are unsure.
          </p>
          <div style={{ marginTop: 18 }}>
            <Link href="/" style={{ color: '#CFE0F2', fontSize: 14, fontWeight: 500 }}>← Back to home</Link>
          </div>
        </div>
      </section>

      <script
        dangerouslySetInnerHTML={{
          __html: `(function(){try{var els=document.querySelectorAll('.reveal');if(!('IntersectionObserver' in window)){els.forEach(function(e){e.classList.add('in')});}else{var io=new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target);}})},{threshold:0.1});els.forEach(function(e){io.observe(e)});}}catch(e){document.querySelectorAll('.reveal').forEach(function(x){x.classList.add('in')});}})();`,
        }}
      />
      <SiteFooter />
    </main>
  );
}
